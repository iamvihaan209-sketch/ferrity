package net.minecraft.advancements.criterion;

import com.mojang.serialization.Codec;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public interface CollectionContentsPredicate<T, P extends Predicate<T>> extends Predicate<Iterable<? extends T>> {
    List<P> unpack();

    static <T, P extends Predicate<T>> Codec<CollectionContentsPredicate<T, P>> codec(Codec<P> elementCodec) {
        return elementCodec.listOf().xmap(CollectionContentsPredicate::of, CollectionContentsPredicate::unpack);
    }

    @SafeVarargs
    static <T, P extends Predicate<T>> CollectionContentsPredicate<T, P> of(P... predicates) {
        return of(List.of(predicates));
    }

    static <T, P extends Predicate<T>> CollectionContentsPredicate<T, P> of(List<P> predicates) {
        return (CollectionContentsPredicate<T, P>)(switch (predicates.size()) {
            case 0 -> new CollectionContentsPredicate.Zero();
            case 1 -> new CollectionContentsPredicate.Single(predicates.getFirst());
            default -> new CollectionContentsPredicate.Multiple(predicates);
        });
    }

    public record Multiple<T, P extends Predicate<T>>(List<P> tests) implements CollectionContentsPredicate<T, P> {
        public boolean test(Iterable<? extends T> values) {
            List<Predicate<T>> testsToMatch = new ArrayList<>(this.tests);

            for (T value : values) {
                testsToMatch.removeIf(p -> p.test(value));
                if (testsToMatch.isEmpty()) {
                    return true;
                }
            }

            return false;
        }

        @Override
        public List<P> unpack() {
            return this.tests;
        }
    }

    public record Single<T, P extends Predicate<T>>(P test) implements CollectionContentsPredicate<T, P> {
        public boolean test(Iterable<? extends T> values) {
            for (T value : values) {
                if (this.test.test(value)) {
                    return true;
                }
            }

            return false;
        }

        @Override
        public List<P> unpack() {
            return List.of(this.test);
        }
    }

    public static class Zero<T, P extends Predicate<T>> implements CollectionContentsPredicate<T, P> {
        public boolean test(Iterable<? extends T> values) {
            return true;
        }

        @Override
        public List<P> unpack() {
            return List.of();
        }
    }
}
