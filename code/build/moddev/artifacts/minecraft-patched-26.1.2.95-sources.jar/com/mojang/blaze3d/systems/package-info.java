@NullMarked
@OnlyIn(Dist.CLIENT)
package com.mojang.blaze3d.systems;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.NullMarked;
